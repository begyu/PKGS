Tab Separated Values DataBase (http://tsvdb.sourceforge.net/)
